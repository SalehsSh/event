$ = jQuery;
$(() => {
	
})