# Change this file name to `config.py`

INPUT_FILE_PATH = 'input.xlsx'
OUTPUT_FILE_PATH = 'output.xlsx'
ADMIN_PASSWORD = '1234'
DOMAIN_NAME = 'http://127.0.0.1:8000'

PAGE_TITLE = 'QR Ticket'
EVENT_NAME = '1989 EVENT'
